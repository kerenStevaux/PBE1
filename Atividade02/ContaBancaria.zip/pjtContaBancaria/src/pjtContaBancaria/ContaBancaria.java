package pjtContaBancaria;

import java.util.Scanner;

public class ContaBancaria {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Informe o número da conta bancaria: ");
		int numeroConta = sc.nextInt();
		
		System.out.println("Informe o número do titular da conta: ");
		String nomeTitular = sc.next();
		
		System.out.println("Qual o saldo atual da conta?: ");
		double saldo = sc.nextInt();
		
		
		System.out.println("Opções");
		System.out.println("1. Depositar");
		System.out.println("2. Sacar");
		System.out.println("3. Ver saldo da conta bancaria");
		System.out.println("Escolha uma opção:");
		int escolha = sc.nextInt();
		
		
		if (escolha == 1) {
			System.out.println("Quanto você quer depositar? ");
			
		}

	}

}