package pjtContaBancaria;

public class Aplicacao {
	//Atributos
	private int numeroConta;
	private String nomeTitular;
	private double saldoAtual;
	
	//Construtores
	public Aplicacao() {
		
	}
	
	public Aplicacao(int numeroConta, String nomeTitular, double saldoAtual) {
		this.numeroConta = numeroConta;
		this.nomeTitular = nomeTitular;
		this.saldoAtual = saldoAtual;
	}
	
	//getters setters
	public int getNumeroConta() {
		return numeroConta;
	}
	
	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}
	
	public String getnomeTitular() {
		return nomeTitular;
	}
	
	public void setnomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}
	
	public

}
