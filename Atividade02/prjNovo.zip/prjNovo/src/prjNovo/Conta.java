package prjNovo;

public class Conta {
	//atributos, classificado na classe para reutilização do codigo
	private int numeroConta;
	private String nomeTitular;
	private double saldoAtual;
	
	//construtores, 
	public Conta() {
		
	}
	
	public Conta(int numeroConta, String nomeTitular, double saldoAtual) {
		this.numeroConta = numeroConta;
		this.nomeTitular = nomeTitular;
		this.saldoAtual = saldoAtual;
	}
	
	public Conta(int numeroConta, String nomeTitular) {
		this.numeroConta = numeroConta;
		this.nomeTitular = nomeTitular;
		this.saldoAtual = 0;
	}
	
	// getters ands setters 
	

}
