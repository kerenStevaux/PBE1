package prjCarro;

import java.util.Scanner;

public class andardecarro {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Qual a marca do seu carro? ");
		String marca = sc.next();
		
		System.out.println("Qual o modelo do seu carro? ");
		String modelo = sc.next();
		
		System.out.println("Qual a velocidade do seu carro? ");
		int velocidade = sc.nextInt();
		
		System.out.println("Você quer acelerar ou frear?");
		System.out.println("Opções:");
		System.out.println("1. Acelerar");
		System.out.println("2. Frear");
		System.out.println("Escolha uma opção: ");
		int escolha = sc.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto você quer acelerar? ");
			int valor = sc.nextInt();
			velocidade += valor;
		}
			
		else if(escolha == 2) {
			System.out.println("Qaunto você quer desacelerar");
			int valor = sc.nextInt();
			velocidade -= valor;
		}
		
		sc.close();
		}
	}

