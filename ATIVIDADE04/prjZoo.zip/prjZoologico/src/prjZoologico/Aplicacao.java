package prjZoologico;

public class Aplicacao {

	public static void main(String[] args) {
		ClasseAnimal elefante = new ClasseAnimal();
		elefante.setNome("Dumbo");
		elefante.setPeso(600);
		

		
		ClasseAnimal girafa = new ClasseAnimal("Girafales", "Russa", "Femea", 50);
		
		SubClasseCarnivoro leao = new SubClasseCarnivoro();
		leao.atributoNome = "Liona";
		leao.atributoRaca = "Australeandro";
		leao.atributoSexo = "Femea";
		leao.atributoPeso = 125;
		
		elefante.exibirInf();
		
		elefante.metodoComer(); 
		
		elefante.exibirInf();
		
		girafa.exibirInf();
		
		elefante.metodoEmitirSom();
		girafa.metodoEmitirSom();
		leao.metodoEmitirSom();
	

	}
	

}
