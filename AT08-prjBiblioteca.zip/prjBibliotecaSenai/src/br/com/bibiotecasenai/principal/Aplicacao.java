package br.com.bibliotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Bibliotecario;

public class Aplicacao {

	public static <Usuario> void main(String[] args) {

		br.com.bibliotecasenai.usuarios.Usuario usuario1 = new br.com.bibliotecasenai.usuarios.Usuario("João", 25,
				"111.111.111-11");
		br.com.bibliotecasenai.usuarios.Usuario usuario2 = new br.com.bibliotecasenai.usuarios.Usuario("Maria", 30,
				"222.222.222-22");

		Bibliotecario bibliotecario = new Bibliotecario("Ana", 40, "M123");

		Livro[] livros = new Livro[10];

		for (int i = 0; i < 10; i++) {

		}
	}
}