package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	// atributos
	private String matricula;

	// metodos
	public void realizarEmprestimo(String nomeLivro) {
		System.out.println(getNome() + ", realizou empréstimo do livro: " + nomeLivro);
	}

	public void devolverLivro(String nomeLivro) {
		System.out.println(getNome() + ", devolveu livro: " + nomeLivro);
	}
}
