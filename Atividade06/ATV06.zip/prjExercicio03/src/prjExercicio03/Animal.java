package prjExercicio03;

public class Animal {
	// atributos
	String nome;
	int idade;
	String raca;
	
	
	// construtor
	public Animal() {
		this.nome = "";
		this.raca = "";
		this.idade= 4;
		
		public Animal(String nome, String raca, int idade) {
			this.nome = nome;
			this.raca = raca;
			this.idade = idade; 
		}
		
		//Metodo
		public void emitirSom() {
			System.out.println("O Animal fez um som");
		}

}
