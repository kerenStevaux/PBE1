package prjExercicio02;

public class Aplicacao {

	public static void main(String[] args) {
		// três livros
		Livro livro1 = new Livro("Harry Potter", "Emma Waton", 1023, 59.90);
		Livro livro2 = new Livro("1984", "George Orwell", 334, 45.00);
		Livro livro3 = new Livro("Alice no País das Maravilhas", "Chapeleiro Maluco", 179, 89.90);

		// antes
		System.out.println("Informações antes do desconto:");
		livro1.exibirInfo();
		livro2.exibirInfo();
		livro3.exibirInfo();

		// aplicando desconto
		livro1.aplicarDesconto();
		livro2.aplicarDesconto();
		livro3.aplicarDesconto();

		// depois
		System.out.println("Informações após o desconto:");
		livro1.exibirInfo();
		livro2.exibirInfo();
		livro3.exibirInfo();
	}
}