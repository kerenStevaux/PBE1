package prjExercicio01;

public class Aplicacao {

	public static void main(String[] args) {

		Carro carro01 = new Carro();
		carro01.modelo = "HR-V2022";

		Carro marca = new Carro();
		carro01.marca = "Honda";

		Carro placa = new Carro();
		carro01.placa = 123455;

		Carro turbo = new Carro();
		carro01.turbo = "Ultra plaster master";

		Carro carro02 = new Carro();
		carro02.modelo = "Nivus2020";

		Carro marca2 = new Carro();
		carro02.marca = "Volkswagen";

		Carro placa2 = new Carro();
		carro02.placa = 876540;

		Carro turbo2 = new Carro();
		carro02.turbo = "Plaster master";

		carro01.exibirInfo();

		carro02.exibirInfo();

	}

}
